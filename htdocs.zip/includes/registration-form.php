<form method="post" class="registration-form">
    <div class="form-group">
        <label for="username">Ім'я користувача:</label>
        <input type="text" id="username" name="username" required>
    </div>
    
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
    </div>
    
    <!-- Інші поля форми -->
    
    <button type="submit" name="register" class="btn">Зареєструватися</button>
</form>